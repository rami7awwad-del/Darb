import 'package:darb/core/errors/error_messages.dart';
import 'package:darb/core/errors/errors_code.dart';
import 'package:darb/core/errors/remote_exceptions.dart';
import 'package:darb/core/models/base_state.dart';
import 'package:darb/core/models/enums/state_value.dart';
import 'package:darb/features/support/data/models/about_model.dart';
import 'package:darb/features/support/data/repositories/support_repository.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

/// ورقة "حول التطبيق".
class AboutCubit extends Cubit<BaseState<AboutModel>> {
  AboutCubit(this._repository)
      : super(const BaseState<AboutModel>(stateValue: StateValue.loading));

  final SupportRepository _repository;

  Future<void> load() async {
    emit(const BaseState<AboutModel>(stateValue: StateValue.loading));
    try {
      final about = await _repository.getAbout();
      if (isClosed) return;
      emit(BaseState<AboutModel>(stateValue: StateValue.loaded, data: about));
    } on RemoteExceptions catch (e) {
      if (isClosed) return;
      emit(BaseState<AboutModel>(
        stateValue: StateValue.error,
        errorMessage: e.errorMsg,
      ));
    } catch (_) {
      if (isClosed) return;
      emit(BaseState<AboutModel>(
        stateValue: StateValue.error,
        errorMessage: ErrorCode.UNKNOWN.getLocalizedMessage(),
      ));
    }
  }
}
